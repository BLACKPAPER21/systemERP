"use server";

import { db } from "@/db";
import { salesOrders } from "@/db/schema/sales";
import { customers, users } from "@/db/schema/master";
import { desc, eq, sql } from "drizzle-orm";

export type ItemDaftarBayar = {
  id: string | number;
  tanggal: string | Date | null;
  nominal: number;
  metode?: string | null;
  keterangan?: string | null;
};

export type PesananPenjualanItem = {
  id: number;
  nomor: string;
  tanggal: Date;
  status: string;
  total: number;
  namaCustomer: string | null;
  dibuatOleh: string | null;
  daftarBayar: ItemDaftarBayar[];
  totalBayar: number;
  sisaPiutang: number;
  statusPelunasan: "Lunas" | "Belum Lunas";
};

function hitungPelunasan(totalNilai: number, daftarBayar: ItemDaftarBayar[]) {
  const totalAman = Math.max(0, Number(totalNilai || 0));
  const totalBayar = daftarBayar.reduce(
    (acc, item) => acc + Math.max(0, Number(item.nominal || 0)),
    0
  );
  const sisaPiutang = Math.max(0, totalAman - totalBayar);
  const statusPelunasan: "Lunas" | "Belum Lunas" =
    totalAman > 0 && sisaPiutang === 0 ? "Lunas" : "Belum Lunas";

  return {
    totalBayar,
    sisaPiutang,
    statusPelunasan,
  };
}

export async function getPesananPenjualan() {
  try {
    const rows = await db
      .select({
        id: salesOrders.id,
        nomor: salesOrders.nomor,
        tanggal: salesOrders.tanggal,
        status: salesOrders.status,
        total: salesOrders.total,
        namaCustomer: customers.nama,
        dibuatOleh: users.nama,
      })
      .from(salesOrders)
      .leftJoin(customers, eq(salesOrders.customerId, customers.id))
      .leftJoin(users, eq(salesOrders.dibuatOleh, users.id))
      .orderBy(desc(salesOrders.id));

    // TODO: Jika tabel pembayaran / invoice sudah tersedia di schema,
    // ambil riwayat pembayaran per SO dan petakan ke `daftarBayar`.
    const data: PesananPenjualanItem[] = rows.map((row) => {
      const daftarBayar: ItemDaftarBayar[] = [];
      const totalNilai = Number(row.total || 0);
      const { totalBayar, sisaPiutang, statusPelunasan } = hitungPelunasan(
        totalNilai,
        daftarBayar
      );

      return {
        id: row.id,
        nomor: row.nomor,
        tanggal: row.tanggal,
        status: row.status,
        total: totalNilai,
        namaCustomer: row.namaCustomer,
        dibuatOleh: row.dibuatOleh,
        daftarBayar,
        totalBayar,
        sisaPiutang,
        statusPelunasan,
      };
    });

    const ringkasan = await db
      .select({
        totalPendapatan: sql<number>`COALESCE(SUM(CASE WHEN ${salesOrders.status} IN ('confirmed', 'invoiced') THEN ${salesOrders.total} ELSE 0 END), 0)`,
        pesananDraft: sql<number>`COUNT(CASE WHEN ${salesOrders.status} = 'draft' THEN 1 END)`,
        pesananConfirmed: sql<number>`COUNT(CASE WHEN ${salesOrders.status} = 'confirmed' THEN 1 END)`,
        totalPesanan: sql<number>`COUNT(${salesOrders.id})`,
      })
      .from(salesOrders);

    return {
      success: true,
      data,
      ringkasan: ringkasan[0],
    };
  } catch (error) {
    console.error("Gagal mengambil data pesanan penjualan:", error);
    return {
      success: false,
      data: [] as PesananPenjualanItem[],
      ringkasan: {
        totalPendapatan: 0,
        pesananDraft: 0,
        pesananConfirmed: 0,
        totalPesanan: 0,
      },
      error: "Terjadi kesalahan pada server saat memuat data.",
    };
  }
}